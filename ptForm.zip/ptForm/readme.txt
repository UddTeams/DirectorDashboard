How to run?
-----------
	
	-install Lamp, Wamp Server for php
	-import db (ptForm.sql)
	-check dbService.php file for db Configuration
	-then run index.html


Other Details:

 Js file for create entry in db.
 --------------------------------

  Path:  js->form.js

 php code exist in Src.
 ----------------------

	db.php -> for db connection
	createService.php -> take post date and put the data into db